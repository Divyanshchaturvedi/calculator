function clearScreen() {
    document.getElementById("show").value = "";
}
function display(value) {
    document.getElementById("show").value += value;
}
function calculate() {
    var p = document.getElementById("show").value;
    var q = eval(p);
    document.getElementById("show").value = q;
}